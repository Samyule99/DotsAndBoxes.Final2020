package uk.ac.bournemouth.ap.dotsandboxes

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import org.example.student.dotsboxgame.StudentDotsBoxGame
import uk.ac.bournemouth.ap.dotsandboxeslib.DotsAndBoxesGame
import uk.ac.bournemouth.ap.dotsandboxeslib.HumanPlayer
import java.lang.IllegalStateException
import kotlin.math.sqrt


class DotsAndBoxesView : View, DotsAndBoxesGame.GameChangeListener {

    constructor(context: Context?) : super(context)
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
                                                                                   )

    private val colCount = 5
    private val rowCount = 5

    private var mGridPaint: Paint
    private var mNoPlayerPaint: Paint
    private var mNoLinePaint: Paint
    private var mActiveLinePaint: Paint
    private var mOwnedBoxP1: Paint
    private var mOwnedBoxP2: Paint
    private var finalPaint: Paint
    private var wordPaint: Paint
    private var theWinningPlayerPaint: Paint
    private var playerOnePaint: Paint
    private var playerTwoPaint: Paint


    private val myGestureDetector = GestureDetector(context, myGestureListener())

    var theGame = StudentDotsBoxGame(colCount - 1, rowCount - 1, listOf(HumanPlayer(), HumanPlayer()))
        set(value) {
            field.removeOnGameChangeListener(this)
            field = value
            value.addOnGameChangeListener(this)
            invalidate()
        }

    init {

        theGame.addOnGameChangeListener(this)

        mGridPaint = Paint().apply {
            style = Paint.Style.FILL
            color = Color.DKGRAY
        }

        mNoPlayerPaint = Paint().apply {
            style = Paint.Style.FILL
            color = Color.GRAY

        }

        mNoLinePaint = Paint().apply {
            style = Paint.Style.STROKE
            color = Color.BLACK
            strokeWidth = 25f
        }

        mActiveLinePaint = Paint().apply {
            style = Paint.Style.STROKE
            color = Color.parseColor("#E7A9C6")
            strokeWidth = 25f
        }
        mOwnedBoxP1 = Paint().apply {
            style = Paint.Style.FILL
            color = Color.RED

        }
        mOwnedBoxP2 = Paint().apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#06470a")

        }
        finalPaint = Paint().apply {
            style = Paint.Style.STROKE
            color = Color.CYAN
            strokeWidth = 25f

        }
        wordPaint = Paint().apply {
            color = Color.BLUE
            textSize = 100f
            typeface = Typeface.SANS_SERIF

        }
        theWinningPlayerPaint = Paint().apply {
            color = Color.parseColor("#eaa81b")
            textSize = 100f
            typeface = Typeface.SANS_SERIF
            style = Paint.Style.FILL

        }
        playerOnePaint = Paint().apply {
            color = Color.RED
            textSize = 100f
            typeface = Typeface.SANS_SERIF
            style = Paint.Style.FILL

        }
        playerTwoPaint = Paint().apply {
            color = Color.parseColor("#06470a")
            textSize = 100f
            typeface = Typeface.SANS_SERIF
            style = Paint.Style.FILL

        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        var lineAtPos: Boolean

        val chosenDiameter: Float
        var paint: Paint

        val viewWidth: Float = width.toFloat()
        val viewHeight: Float = height.toFloat()

        val diameterX: Float = viewWidth / colCount.toFloat()
        val diameterY: Float = viewHeight / rowCount.toFloat()



        if (diameterX < diameterY)
            chosenDiameter = diameterX
        else
            chosenDiameter = diameterY

        canvas.drawRect(0.toFloat(), 0.toFloat(), viewWidth, viewHeight, mGridPaint)
        val radius = chosenDiameter / 5
        var xMargin = radius.toInt()
        var yMargin = radius.toInt()


        for (col in 0 until colCount - 1) {
            for (row in 0 until rowCount - 1) {

                val boxStartX = chosenDiameter * col + radius
                val boxStartY = chosenDiameter * row + radius
                val boxFinishX = chosenDiameter * col + radius + chosenDiameter
                val boxFinishY = chosenDiameter * row + radius + chosenDiameter

                if (theGame.boxes[col, row].owningPlayer == theGame.players[0]) {
                    finalPaint = mOwnedBoxP1
                } else
                    if (theGame.boxes[col, row].owningPlayer == theGame.players[1]) {
                        finalPaint = mOwnedBoxP2

                    } else finalPaint = mGridPaint
                canvas.drawRect(
                    boxStartX + xMargin,
                    boxStartY + yMargin,
                    boxFinishX + xMargin,
                    boxFinishY + yMargin,
                    finalPaint
                               )
            }
        }

        var playerNumber = 0
        var scoreCount = 0
        for (player in theGame.players) {
            playerNumber += 1
            scoreCount = 0
            for (box in theGame.boxes) {
                if (box.owningPlayer == player) {
                    scoreCount += 1
                }
                if (playerNumber - 1 == theGame.players.indexOf(theGame.currentPlayer)) {
                    wordPaint.style = Paint.Style.FILL
                } else {
                    wordPaint.style = Paint.Style.STROKE
                }
                if (theGame.isFinished) {
                    wordPaint.style = Paint.Style.FILL
                }
            }
            if(playerNumber == 1){wordPaint.color = playerOnePaint.color} else { wordPaint.color =
                playerTwoPaint.color}
            canvas.drawText(
                "Player $playerNumber: $scoreCount", xMargin * 7f,
                yMargin.toFloat() * 23f + (yMargin * 3) * playerNumber, wordPaint

                           )



           }
        if(theGame.isFinished) {
            var theWinner: Int
            if (scoreCount > theGame.boxes.count() / 2) {
                theWinner = 2
            } else {
                theWinner = 1
            }
            canvas.drawText(
                "Player $theWinner Wins!", xMargin.toFloat() * 7f,
                yMargin.toFloat() * 32f, theWinningPlayerPaint
                           )
        }


        for (col in 0 until colCount - 1) {                                                         // Lines for Coloumns
            for (row in 0 until rowCount) {

                val cx = chosenDiameter * col + radius
                val cy = chosenDiameter * row + radius

                lineAtPos = theGame.lines[col, row * 2].isDrawn
                if (lineAtPos == true) {
                    finalPaint = mActiveLinePaint
                } else {
                    finalPaint = mNoPlayerPaint
                }

                canvas.drawLine(
                    cx + xMargin,
                    cy + yMargin,
                    cx + xMargin + chosenDiameter,
                    cy + yMargin,
                    finalPaint
                               )
            }
        }
        for (col in 0 until colCount) {                                                             // Lines for Rows
            for (row in 0 until rowCount - 1) {

                val cx = chosenDiameter * col + radius
                val cy = chosenDiameter * row + radius

                lineAtPos = theGame.lines[col, row * 2 + 1].isDrawn
                if (lineAtPos == true) {
                    finalPaint = mActiveLinePaint
                } else {
                    finalPaint = mNoPlayerPaint
                }

                canvas.drawLine(
                    cx + xMargin,
                    cy + yMargin,
                    cx + xMargin,
                    cy + yMargin + chosenDiameter,
                    finalPaint
                               )

            }

        }

        for (col in 0 until colCount) {                                                             // Circles (Dots)
            for (row in 0 until rowCount) {
                paint = mNoPlayerPaint


                val cx = chosenDiameter * col + radius
                val cy = chosenDiameter * row + radius

                canvas.drawCircle(cx + xMargin, cy + yMargin, radius, paint)

            }

        }

    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {

        return myGestureDetector.onTouchEvent(ev) || super.onTouchEvent(ev)
    }

    inner class myGestureListener : GestureDetector.SimpleOnGestureListener() {

        override fun onDown(ev: MotionEvent): Boolean {
            return true
        }

        override fun onSingleTapUp(ev: MotionEvent): Boolean {

            val chosenDiameter: Float
            val viewWidth: Float = width.toFloat()
            val viewHeight: Float = height.toFloat()
            val diameterX: Float = viewWidth / colCount.toFloat()
            val diameterY: Float = viewHeight / rowCount.toFloat()

            if (diameterX < diameterY)
                chosenDiameter = diameterX
            else
                chosenDiameter = diameterY

            val radius = chosenDiameter / 5
            var xMargin = radius.toInt()
            var yMargin = radius.toInt()

            val boxX: Int = (ev.x.toInt() - xMargin) / chosenDiameter.toInt()
            val boxY: Int = (ev.y.toInt() - yMargin) / chosenDiameter.toInt()


            val topY = yMargin + boxY * chosenDiameter
            val middleY = topY + chosenDiameter / 2
            val bottomY = topY + chosenDiameter

            val leftX = xMargin + boxX * chosenDiameter
            val middleX = leftX + chosenDiameter / 2
            val rightX = leftX + chosenDiameter

            var closestLine = Side.TOP
            var closestDistance = distance(ev.x, ev.y, middleX, topY) // top line


            run {                                                                                   // Left Line
                val leftDistance = distance(ev.x, ev.y, leftX, middleY)
                if (leftDistance < closestDistance) {
                    closestLine = Side.LEFT
                    closestDistance = leftDistance
                }
            }

            run {                                                                                    // Right Line
                val rightDistance = distance(ev.x, ev.y, rightX, middleY)
                if (rightDistance < closestDistance) {
                    closestLine = Side.RIGHT
                    closestDistance = rightDistance
                }
            }

            run {                                                                                   // Bottom Line
                val bottomDistance = distance(ev.x, ev.y, middleX, bottomY)
                if (bottomDistance < closestDistance) {
                    closestLine = Side.BOTTOM
                    closestDistance = bottomDistance
                }
            }

            val lineX: Int
            val lineY: Int

            when (closestLine) {
                Side.TOP    -> {
                    lineX = boxX
                    lineY = boxY * 2
                }
                Side.LEFT   -> {
                    lineX = boxX
                    lineY = boxY * 2 + 1
                }
                Side.BOTTOM -> {
                    lineX = boxX
                    lineY = boxY * 2 + 2
                }
                Side.RIGHT  -> {
                    lineX = boxX + 1
                    lineY = boxY * 2 + 1
                }
            }

            if (theGame.lines.isValid(lineX, lineY)) {
                val line = theGame.lines[lineX, lineY]
                try {
                    line.drawLine()
                } catch (e: IllegalStateException) {
                }
            } else {
                return false
            }

            return true
        }

    }

    override fun onGameChange(game: DotsAndBoxesGame) {
        invalidate()
    }

}

fun square(x: Float) = x * x

fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
    return sqrt(square(x1 - x2) + square(y1 - y2))
}

enum class Side {
    TOP, LEFT, BOTTOM, RIGHT
}







