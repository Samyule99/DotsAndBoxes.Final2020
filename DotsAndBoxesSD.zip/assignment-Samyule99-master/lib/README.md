## Module lib
This is the base game code that is provided to help implement the game. It provides some structure
as needed for Testing but leaves you to do your own implementation. You are not expected to change 
this code, and don't need to to be able to allow the tests to still pass. Tests may not be changed 
in spirit, preferably not at all. You can add your own tests in your logic module or in the app
module.