package org.example.student.dotsboxgame

import uk.ac.bournemouth.ap.dotsandboxeslib.*
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.Matrix
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.MutableMatrix
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.MutableSparseMatrix
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.SparseMatrix


class StudentDotsBoxGame(columns: Int, rows: Int, players: List<Player>) :
    AbstractDotsAndBoxesGame() {

    override val players: MutableList<Player> = players.toMutableList()

    override var currentPlayer: Player = players[0]

    override val boxes: Matrix<StudentBox> = MutableMatrix(columns, rows, ::StudentBox)

    override val lines: SparseMatrix<StudentLine> =
        MutableSparseMatrix(columns + 1, rows * 2 + 1, ::StudentLine) { x, y ->
            y % 2 == 1 || x < columns
        }

    override var isFinished: Boolean = false

    override fun playComputerTurns() {
        var current = currentPlayer
        while (current is ComputerPlayer && !isFinished) {
            current.makeMove(this)
            current = currentPlayer
        }
    }


    inner class StudentLine(lineX: Int, lineY: Int) : AbstractLine(lineX, lineY) {
        override var isDrawn: Boolean = false


        override val adjacentBoxes: Pair<StudentBox?, StudentBox?>
            get() {
                val box1X: Int
                val box1Y: Int
                val box2X: Int
                val box2Y: Int

                if (lineY % 2 == 0) {                                                               // Horizontal Line
                    box1X = lineX
                    box2X = lineX
                    box1Y = lineY / 2 - 1
                    box2Y = lineY / 2

                } else {                                                                             // Vertical Line
                    box1X = lineX - 1
                    box2X = lineX
                    box1Y = lineY / 2
                    box2Y = lineY / 2
                }
                val box1 = if (boxes.isValid(box1X, box1Y)) boxes[box1X, box1Y] else null
                val box2 = if (boxes.isValid(box2X, box2Y)) boxes[box2X, box2Y] else null
                return Pair(box1, box2)
            }

        override fun drawLine() {

            var extraMoveAcquired = false
            if (isDrawn) throw IllegalStateException("This line already exists") else {
                if (!lines[lineX, lineY].isDrawn && !isFinished) {
                    lines[lineX, lineY].isDrawn = true
                    for (box in adjacentBoxes.toList()) {
                        if (box != null) {
                            var boxLines = 0
                            for (line in box.boundingLines) {
                                if (lines[line.lineX, line.lineY].isDrawn) {
                                    boxLines += 1
                                }
                                if (boxLines == 4) {
                                    boxes[box.boxX, box.boxY].owningPlayer = currentPlayer
                                    extraMoveAcquired = true
                                    var ownedLine2 = 0
                                    for (box in boxes) {
                                        if (box.owningPlayer == null) {
                                            ownedLine2 += 1
                                        }
                                    }
                                    if (ownedLine2 == 0) {
                                        isFinished = true
                                    }
                                }
                            }
                        }
                    }
                }
                if (!extraMoveAcquired) {
                    val playerNo = players.indexOf(currentPlayer)

                    if (playerNo == players.size - 1) {
                        currentPlayer = players[0]
                    } else {
                        currentPlayer = players[playerNo + 1]
                    }
                }

                playComputerTurns()

                fireGameChange()
            }
            val playerScores =
                getScores().mapIndexed { index, score -> Pair(players[index], score) }

            if (lines.all { it.isDrawn }) {
                fireGameOver(playerScores)
            }
        }
    }

    inner class StudentBox(boxX: Int, boxY: Int) : AbstractBox(boxX, boxY) {

        override var owningPlayer: Player? = null


        override val boundingLines: Iterable<DotsAndBoxesGame.Line>
            get() = listOf(

                lines[boxX, boxY * 2],                                                              // TOP
                lines[boxX, boxY * 2 + 1],                                                          // LEFT
                lines[boxX + 1, boxY * 2 + 1],                                                      // RIGHT
                lines[boxX, boxY * 2 + 2]                                                           // BOTTOM
                          )
    }
}